istall packet:
# npm install

start test:
# npm run wdio